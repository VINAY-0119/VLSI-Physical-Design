add_search_path ./inputs -library -both
read_library -liberty -both \
    /home/chethan/BMSIT_WORKSHOP/synthesis/inputs/slow_vdd1v0_basicCells.lib \
    /home/chethan/BMSIT_WORKSHOP/synthesis/inputs/slow_vdd1v0_basicCells_hvt.lib \
    /home/chethan/BMSIT_WORKSHOP/synthesis/inputs/slow_vdd1v0_basicCells_lvt.lib

