
//input ports
add mapped point clk_i clk_i -type PI PI
add mapped point rst_i rst_i -type PI PI
add mapped point wr_rd_i wr_rd_i -type PI PI
add mapped point addr_i[3] addr_i[3] -type PI PI
add mapped point addr_i[2] addr_i[2] -type PI PI
add mapped point addr_i[1] addr_i[1] -type PI PI
add mapped point addr_i[0] addr_i[0] -type PI PI
add mapped point wdata_i[7] wdata_i[7] -type PI PI
add mapped point wdata_i[6] wdata_i[6] -type PI PI
add mapped point wdata_i[5] wdata_i[5] -type PI PI
add mapped point wdata_i[4] wdata_i[4] -type PI PI
add mapped point wdata_i[3] wdata_i[3] -type PI PI
add mapped point wdata_i[2] wdata_i[2] -type PI PI
add mapped point wdata_i[1] wdata_i[1] -type PI PI
add mapped point wdata_i[0] wdata_i[0] -type PI PI
add mapped point valid_i valid_i -type PI PI

//output ports
add mapped point rdata_o[7] rdata_o[7] -type PO PO
add mapped point rdata_o[6] rdata_o[6] -type PO PO
add mapped point rdata_o[5] rdata_o[5] -type PO PO
add mapped point rdata_o[4] rdata_o[4] -type PO PO
add mapped point rdata_o[3] rdata_o[3] -type PO PO
add mapped point rdata_o[2] rdata_o[2] -type PO PO
add mapped point rdata_o[1] rdata_o[1] -type PO PO
add mapped point rdata_o[0] rdata_o[0] -type PO PO
add mapped point ready_o ready_o -type PO PO

//inout ports




//Sequential Pins
add mapped point rdata_o[2]/q rdata_o_reg[2]/Q -type DFF DFF
add mapped point rdata_o[1]/q rdata_o_reg[1]/Q -type DFF DFF
add mapped point rdata_o[3]/q rdata_o_reg[3]/Q -type DFF DFF
add mapped point rdata_o[4]/q rdata_o_reg[4]/Q -type DFF DFF
add mapped point rdata_o[5]/q rdata_o_reg[5]/Q -type DFF DFF
add mapped point rdata_o[6]/q rdata_o_reg[6]/Q -type DFF DFF
add mapped point rdata_o[7]/q rdata_o_reg[7]/Q -type DFF DFF
add mapped point rdata_o[0]/q rdata_o_reg[0]/Q -type DFF DFF
add mapped point mem[1][1]/q mem_reg[1][1]/Q -type DFF DFF
add mapped point mem[6][2]/q mem_reg[6][2]/Q -type DFF DFF
add mapped point mem[6][3]/q mem_reg[6][3]/Q -type DFF DFF
add mapped point mem[6][5]/q mem_reg[6][5]/Q -type DFF DFF
add mapped point mem[6][4]/q mem_reg[6][4]/Q -type DFF DFF
add mapped point mem[6][7]/q mem_reg[6][7]/Q -type DFF DFF
add mapped point mem[6][6]/q mem_reg[6][6]/Q -type DFF DFF
add mapped point mem[6][0]/q mem_reg[6][0]/Q -type DFF DFF
add mapped point mem[6][1]/q mem_reg[6][1]/Q -type DFF DFF
add mapped point mem[5][1]/q mem_reg[5][1]/Q -type DFF DFF
add mapped point mem[5][2]/q mem_reg[5][2]/Q -type DFF DFF
add mapped point mem[5][4]/q mem_reg[5][4]/Q -type DFF DFF
add mapped point mem[3][0]/q mem_reg[3][0]/Q -type DFF DFF
add mapped point mem[5][6]/q mem_reg[5][6]/Q -type DFF DFF
add mapped point mem[5][7]/q mem_reg[5][7]/Q -type DFF DFF
add mapped point mem[4][0]/q mem_reg[4][0]/Q -type DFF DFF
add mapped point mem[3][1]/q mem_reg[3][1]/Q -type DFF DFF
add mapped point mem[5][0]/q mem_reg[5][0]/Q -type DFF DFF
add mapped point mem[5][5]/q mem_reg[5][5]/Q -type DFF DFF
add mapped point mem[3][2]/q mem_reg[3][2]/Q -type DFF DFF
add mapped point mem[3][3]/q mem_reg[3][3]/Q -type DFF DFF
add mapped point mem[3][4]/q mem_reg[3][4]/Q -type DFF DFF
add mapped point mem[3][5]/q mem_reg[3][5]/Q -type DFF DFF
add mapped point mem[3][6]/q mem_reg[3][6]/Q -type DFF DFF
add mapped point mem[3][7]/q mem_reg[3][7]/Q -type DFF DFF
add mapped point mem[1][0]/q mem_reg[1][0]/Q -type DFF DFF
add mapped point mem[1][2]/q mem_reg[1][2]/Q -type DFF DFF
add mapped point mem[5][3]/q mem_reg[5][3]/Q -type DFF DFF
add mapped point mem[1][6]/q mem_reg[1][6]/Q -type DFF DFF
add mapped point mem[1][7]/q mem_reg[1][7]/Q -type DFF DFF
add mapped point mem[2][1]/q mem_reg[2][1]/Q -type DFF DFF
add mapped point mem[4][7]/q mem_reg[4][7]/Q -type DFF DFF
add mapped point mem[2][2]/q mem_reg[2][2]/Q -type DFF DFF
add mapped point mem[2][3]/q mem_reg[2][3]/Q -type DFF DFF
add mapped point mem[2][4]/q mem_reg[2][4]/Q -type DFF DFF
add mapped point mem[2][6]/q mem_reg[2][6]/Q -type DFF DFF
add mapped point mem[2][7]/q mem_reg[2][7]/Q -type DFF DFF
add mapped point mem[2][5]/q mem_reg[2][5]/Q -type DFF DFF
add mapped point mem[2][0]/q mem_reg[2][0]/Q -type DFF DFF
add mapped point mem[4][1]/q mem_reg[4][1]/Q -type DFF DFF
add mapped point mem[4][2]/q mem_reg[4][2]/Q -type DFF DFF
add mapped point mem[1][3]/q mem_reg[1][3]/Q -type DFF DFF
add mapped point mem[4][5]/q mem_reg[4][5]/Q -type DFF DFF
add mapped point mem[4][6]/q mem_reg[4][6]/Q -type DFF DFF
add mapped point mem[0][0]/q mem_reg[0][0]/Q -type DFF DFF
add mapped point mem[0][5]/q mem_reg[0][5]/Q -type DFF DFF
add mapped point mem[0][6]/q mem_reg[0][6]/Q -type DFF DFF
add mapped point mem[0][4]/q mem_reg[0][4]/Q -type DFF DFF
add mapped point mem[0][7]/q mem_reg[0][7]/Q -type DFF DFF
add mapped point mem[0][1]/q mem_reg[0][1]/Q -type DFF DFF
add mapped point mem[0][2]/q mem_reg[0][2]/Q -type DFF DFF
add mapped point mem[4][3]/q mem_reg[4][3]/Q -type DFF DFF
add mapped point mem[1][4]/q mem_reg[1][4]/Q -type DFF DFF
add mapped point mem[1][5]/q mem_reg[1][5]/Q -type DFF DFF
add mapped point mem[0][3]/q mem_reg[0][3]/Q -type DFF DFF
add mapped point mem[4][4]/q mem_reg[4][4]/Q -type DFF DFF
add mapped point mem[14][3]/q mem_reg[14][3]/Q -type DFF DFF
add mapped point mem[9][4]/q mem_reg[9][4]/Q -type DFF DFF
add mapped point mem[15][0]/q mem_reg[15][0]/Q -type DFF DFF
add mapped point mem[7][1]/q mem_reg[7][1]/Q -type DFF DFF
add mapped point mem[7][2]/q mem_reg[7][2]/Q -type DFF DFF
add mapped point mem[7][3]/q mem_reg[7][3]/Q -type DFF DFF
add mapped point mem[15][3]/q mem_reg[15][3]/Q -type DFF DFF
add mapped point mem[7][5]/q mem_reg[7][5]/Q -type DFF DFF
add mapped point mem[7][6]/q mem_reg[7][6]/Q -type DFF DFF
add mapped point mem[7][7]/q mem_reg[7][7]/Q -type DFF DFF
add mapped point mem[8][3]/q mem_reg[8][3]/Q -type DFF DFF
add mapped point mem[7][4]/q mem_reg[7][4]/Q -type DFF DFF
add mapped point mem[7][0]/q mem_reg[7][0]/Q -type DFF DFF
add mapped point mem[10][2]/q mem_reg[10][2]/Q -type DFF DFF
add mapped point mem[15][1]/q mem_reg[15][1]/Q -type DFF DFF
add mapped point mem[15][2]/q mem_reg[15][2]/Q -type DFF DFF
add mapped point mem[15][4]/q mem_reg[15][4]/Q -type DFF DFF
add mapped point mem[15][5]/q mem_reg[15][5]/Q -type DFF DFF
add mapped point mem[15][6]/q mem_reg[15][6]/Q -type DFF DFF
add mapped point mem[15][7]/q mem_reg[15][7]/Q -type DFF DFF
add mapped point mem[14][0]/q mem_reg[14][0]/Q -type DFF DFF
add mapped point mem[14][1]/q mem_reg[14][1]/Q -type DFF DFF
add mapped point mem[14][2]/q mem_reg[14][2]/Q -type DFF DFF
add mapped point mem[14][5]/q mem_reg[14][5]/Q -type DFF DFF
add mapped point mem[14][6]/q mem_reg[14][6]/Q -type DFF DFF
add mapped point mem[14][7]/q mem_reg[14][7]/Q -type DFF DFF
add mapped point mem[14][4]/q mem_reg[14][4]/Q -type DFF DFF
add mapped point mem[12][5]/q mem_reg[12][5]/Q -type DFF DFF
add mapped point mem[9][2]/q mem_reg[9][2]/Q -type DFF DFF
add mapped point mem[9][0]/q mem_reg[9][0]/Q -type DFF DFF
add mapped point mem[11][0]/q mem_reg[11][0]/Q -type DFF DFF
add mapped point mem[11][1]/q mem_reg[11][1]/Q -type DFF DFF
add mapped point mem[11][2]/q mem_reg[11][2]/Q -type DFF DFF
add mapped point mem[11][5]/q mem_reg[11][5]/Q -type DFF DFF
add mapped point mem[11][6]/q mem_reg[11][6]/Q -type DFF DFF
add mapped point mem[11][7]/q mem_reg[11][7]/Q -type DFF DFF
add mapped point mem[13][0]/q mem_reg[13][0]/Q -type DFF DFF
add mapped point mem[13][1]/q mem_reg[13][1]/Q -type DFF DFF
add mapped point mem[13][2]/q mem_reg[13][2]/Q -type DFF DFF
add mapped point mem[13][5]/q mem_reg[13][5]/Q -type DFF DFF
add mapped point mem[13][6]/q mem_reg[13][6]/Q -type DFF DFF
add mapped point mem[13][7]/q mem_reg[13][7]/Q -type DFF DFF
add mapped point mem[13][4]/q mem_reg[13][4]/Q -type DFF DFF
add mapped point mem[12][7]/q mem_reg[12][7]/Q -type DFF DFF
add mapped point mem[9][6]/q mem_reg[9][6]/Q -type DFF DFF
add mapped point mem[9][7]/q mem_reg[9][7]/Q -type DFF DFF
add mapped point mem[10][6]/q mem_reg[10][6]/Q -type DFF DFF
add mapped point mem[12][2]/q mem_reg[12][2]/Q -type DFF DFF
add mapped point mem[12][0]/q mem_reg[12][0]/Q -type DFF DFF
add mapped point mem[12][1]/q mem_reg[12][1]/Q -type DFF DFF
add mapped point mem[12][3]/q mem_reg[12][3]/Q -type DFF DFF
add mapped point mem[12][4]/q mem_reg[12][4]/Q -type DFF DFF
add mapped point mem[11][4]/q mem_reg[11][4]/Q -type DFF DFF
add mapped point mem[10][7]/q mem_reg[10][7]/Q -type DFF DFF
add mapped point mem[10][1]/q mem_reg[10][1]/Q -type DFF DFF
add mapped point mem[10][0]/q mem_reg[10][0]/Q -type DFF DFF
add mapped point mem[10][4]/q mem_reg[10][4]/Q -type DFF DFF
add mapped point mem[10][5]/q mem_reg[10][5]/Q -type DFF DFF
add mapped point mem[10][3]/q mem_reg[10][3]/Q -type DFF DFF
add mapped point mem[8][0]/q mem_reg[8][0]/Q -type DFF DFF
add mapped point mem[8][1]/q mem_reg[8][1]/Q -type DFF DFF
add mapped point mem[8][2]/q mem_reg[8][2]/Q -type DFF DFF
add mapped point mem[8][6]/q mem_reg[8][6]/Q -type DFF DFF
add mapped point mem[8][7]/q mem_reg[8][7]/Q -type DFF DFF
add mapped point mem[13][3]/q mem_reg[13][3]/Q -type DFF DFF
add mapped point mem[8][5]/q mem_reg[8][5]/Q -type DFF DFF
add mapped point mem[8][4]/q mem_reg[8][4]/Q -type DFF DFF
add mapped point mem[9][1]/q mem_reg[9][1]/Q -type DFF DFF
add mapped point mem[9][3]/q mem_reg[9][3]/Q -type DFF DFF
add mapped point mem[9][5]/q mem_reg[9][5]/Q -type DFF DFF
add mapped point mem[11][3]/q mem_reg[11][3]/Q -type DFF DFF
add mapped point mem[12][6]/q mem_reg[12][6]/Q -type DFF DFF
add mapped point ready_o/q ready_o_reg/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
