set_db init_lib_search_path ./inputs
# set_db init_hdl_search_path ../rtl/
# read_libs {slow_vdd1v0_basicCells_hvt.lib  slow_vdd1v0_basicCells_lvt.lib slow_vdd1v0_basicCells.lib}


set_db target_library {slow_vdd1v0_basicCells_hvt.lib  slow_vdd1v0_basicCells_lvt.lib slow_vdd1v0_basicCells.lib}
set_db link_library {slow_vdd1v0_basicCells_hvt.lib  slow_vdd1v0_basicCells_lvt.lib slow_vdd1v0_basicCells.lib}


read_hdl ./inputs/memory_rtl.v
elaborate memory 
set po [remove_from_collection [all_inputs] [get_ports clk_i]]
read_sdc ./inputs/memory.sdc

#set_db dft_scan_style muxed_scan 
#set_db dft_prefix dft_
#define_shift_enable -name SE -active high -create_port SE
#check_dft_rules

# set_db syn_generic_effort medium
syn_generic
# set_db syn_map_effort medium
syn_map
# set_db syn_opt_effort medium
syn_opt

#check_dft_rules 
#set_db design:counter .dft_min_number_of_scan_chains 1 
#define_scan_chain -name top_chain -sdi scan_in -sdo scan_out -create_ports  

#connect_scan_chains -auto_create_chains 
#syn_opt -incremental

#report_scan_chains 
#write_dft_atpg -library ../lib/slow_vdd1v0_basiccells.v
write_hdl > outputs/memory_netlist.v
write_sdc > outputs/memory_sdc.sdc
#write_sdf -nonegchecks -edges check_edge -timescale ns -recrem split  -setuphold split > outputs/dft_delays.sdf
#write_scandef > outputs/counter_scanDEF.scandef

gui_show


#######################report commands ####################3

report_qor > ./reports/qor_report.rpt  
report_gates > ./reports/gates_report.rpt
report_area > ./reports/area_report.rpt
report_power > ./reports/power_report.rpt
report_timing > ./reports/timing_report.rpt


######################get_db commands#######################

help inst: *is*
get_db insts -if {.is_sequential==true} 
sizeof_collection [get_db insts -if {.is_sequential==true}]  
get_db insts .ref_name


