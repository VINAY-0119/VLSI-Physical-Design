`include "memory.v"

module tb;
	//parameters
	parameter WIDTH=8;
	parameter DEPTH=16;
	parameter ADDR_WIDTH=$clog2(DEPTH);

	//reg port decleration
	reg clk_i,rst_i;
	reg [ADDR_WIDTH-1:0] addr_i;
	reg [WIDTH-1:0] wdata_i;
	reg wr_rd_en_i, valid_i;

	//output port decleartion
	wire [WIDTH-1:0] rdata_o;
	wire ready_o;

	//declare the memory
	reg [WIDTH-1:0] mem [DEPTH-1:0] ;
	integer i;

 sram  dut (clk_i,rst_i,wr_rd_en_i,addr_i,wdata_i,rdata_o,valid_i,ready_o);

//generate the clk
always begin
	clk_i=0;#5;
	clk_i=1;#5;
end


initial begin
	clk_i=0;
	rst_i=1;
	reset();
	#5;
	rst_i=0;
	write_to_memory();
	read_from_memory();
end

task reset();
begin
	addr_i=0;
	wdata_i=0;
	wr_rd_en_i=0;
	valid_i=0;
end
endtask

task write_to_memory();
begin
	//write  data to the memory 
	for (i=0;i<DEPTH;i=i+1) begin
		@(posedge clk_i);
		valid_i=1;
		wr_rd_en_i=1;
		addr_i=i;
		wdata_i=$random;
		wait (ready_o==1);
	end

		@(posedge clk_i);
			reset();
end
endtask

task read_from_memory();
begin
// read from the meory
	for (i=0;i<DEPTH;i=i+1) begin
		@(posedge clk_i);
			valid_i=1;
			wr_rd_en_i=0;
			addr_i=i;
			wait (ready_o==1);
	end 	
		@(posedge clk_i);
			reset();
end
endtask


initial begin
	#1000 $finish();
end

endmodule
