`timescale 1ns / 1ps
`include "memory.v"

module tb_sram();

    parameter DEPTH=16;
    parameter WIDTH=16;
    parameter ADDR_WIDTH= $clog2(DEPTH);

    reg clk_i,rst_i,wr_rd_i,valid_i;
    reg [ADDR_WIDTH-1:0] addr_i;
    reg [WIDTH-1:0] wdata_i;
    wire [WIDTH-1:0] rdata_o;
    wire ready_o;

    sram DUT(clk_i,rst_i,wr_rd_i,addr_i,wdata_i,rdata_o,valid_i,ready_o);

    //---------------- CLOCK ----------------//
    always #10 clk_i = ~clk_i;

    //---------------- TASKS ----------------//
    task initialize;
        begin
            {clk_i,rst_i,wr_rd_i,valid_i,addr_i,wdata_i} = 0;
        end
    endtask

    task reset;
        begin
            @(negedge clk_i) rst_i = 1;
            @(negedge clk_i) rst_i = 0;
        end
    endtask

    task write(input [ADDR_WIDTH-1:0] addr_in,
               input [WIDTH-1:0] data_in);
        begin
            @(negedge clk_i)
            valid_i = 1;
            wr_rd_i = 1;
            addr_i  = addr_in;
            wdata_i = data_in;
            wait(ready_o);
            @(negedge clk_i)
            valid_i = 0;
        end
    endtask

    task read(input [ADDR_WIDTH-1:0] addr_in);
        begin
            @(negedge clk_i)
            valid_i = 1;
            wr_rd_i = 0;
            addr_i  = addr_in;
            wait(ready_o);
            @(negedge clk_i)
            valid_i = 0;
        end
    endtask

    //---------------- TEST SCENARIOS ----------------//
    integer i;

    initial begin
        initialize;
        reset;

        //  Single write/read
        write(4'd10, 16'd255);
        read(4'd10);

        // Multiple writes and reads
        for(i=0; i<DEPTH; i=i+1) begin
            write(i, i*10);
        end

        for(i=0; i<DEPTH; i=i+1) begin
            read(i);
        end

        // Overwrite same address
        write(4'd5, 16'd100);
        write(4'd5, 16'd200);
        read(4'd5);

        // Read without prior write (should be 0 after reset)
        read(4'd3);

        // ?? 5. Back-to-back operations
        write(4'd1, 16'd11);
        read(4'd1);
        write(4'd2, 16'd22);
        read(4'd2);

        // Random accesses
        repeat(5) begin
            write($urandom_range(0,15), $urandom_range(0,65535));
        end

        repeat(5) begin
            read($urandom_range(0,15));
        end

        //Valid low check (no operation)
        @(negedge clk_i)
        valid_i = 0;
        wr_rd_i = 0;
        addr_i  = 0;

        #100;
        $finish;
    end

    //---------------- MONITOR ----------------//
    initial begin
        $monitor("Time=%0t | valid=%0b ready=%0b wr_rd=%0b addr=%0d wdata=%0d rdata=%0d",
                  $time, valid_i, ready_o, wr_rd_i, addr_i, wdata_i, rdata_o);
    end

endmodule
