xrun -sv -access +rw memory_tb1.v -gui -clean
